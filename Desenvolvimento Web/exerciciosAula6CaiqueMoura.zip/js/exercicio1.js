function exer1() {
    console.log("Carregou");
  }
  