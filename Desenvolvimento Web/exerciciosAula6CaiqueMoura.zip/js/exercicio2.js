function exer2() {
    // obtém o value do campo entrada
    entrada = document.querySelector("#entrada").value;
    // seta o corpo da div saida
    document.querySelector("#saida").innerText = entrada;
  }
  